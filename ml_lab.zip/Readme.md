
### To run locally 
```bash
pip install - r requirements.txt
python main.py
```
### To run on kaggle
1. Upload notebook.
2. Add specified dataset.
3. Run all.

[Dataset](https://www.kaggle.com/neelkamal692/delhi-house-price-prediction/data)